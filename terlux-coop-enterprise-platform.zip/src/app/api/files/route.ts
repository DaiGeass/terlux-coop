// ============================================
// TERLUX COOP - API DE ARCHIVOS (DRIVE)
// Subida real a /public/uploads (almacén local;
// en producción se enruta al storage MinIO/SMB por VPN 10.8.0.20)
// ============================================

import { NextResponse, type NextRequest } from "next/server";
import { eq, desc, like, and, isNull } from "drizzle-orm";
import { writeFile, mkdir } from "fs/promises";
import path from "path";
import { db } from "@/db";
import { files, folders } from "@/db/schema";
import { getSession } from "@/lib/auth";

export async function GET(request: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ success: false }, { status: 401 });

  const { searchParams } = new URL(request.url);
  const folderId = searchParams.get("folderId") || null;
  const type = searchParams.get("type");
  const q = searchParams.get("q");

  const conditions = [];
  if (folderId) conditions.push(eq(files.folderId, folderId));
  else if (searchParams.get("all") !== "1") conditions.push(isNull(files.folderId));
  if (type) conditions.push(eq(files.type, type));
  if (q) conditions.push(like(files.name, `%${q}%`));

  const fileRows = await db
    .select()
    .from(files)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(files.createdAt));

  const folderRows = folderId
    ? []
    : await db.select().from(folders).orderBy(folders.orderIndex);

  return NextResponse.json({ success: true, data: { files: fileRows, folders: folderRows } });
}

export async function POST(request: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ success: false }, { status: 401 });

  const form = await request.formData();
  const uploaded = form.getAll("files") as File[];
  const folderId = (form.get("folderId") as string) || null;
  const category = (form.get("category") as string) || "general";

  if (!uploaded.length) {
    // Crear carpeta
    const name = form.get("name") as string;
    if (name) {
      const [folder] = await db
        .insert(folders)
        .values({ name, userId: session.id, color: "#6366f1" })
        .returning();
      return NextResponse.json({ success: true, data: folder });
    }
    return NextResponse.json({ success: false, error: { code: "NO_FILES", message: "Sin archivos" } }, { status: 400 });
  }

  const uploadDir = path.join(process.cwd(), "public", "uploads");
  await mkdir(uploadDir, { recursive: true });

  const saved = [];
  for (const file of uploaded) {
    const bytes = Buffer.from(await file.arrayBuffer());
    const safeName = `${Date.now()}-${file.name.replace(/[^\w.\-() ]+/g, "_")}`;
    const fsPath = path.join(uploadDir, safeName);
    await writeFile(fsPath, bytes);

    const ext = file.name.split(".").pop()?.toLowerCase() || "";
    let type = "file";
    if (["png", "jpg", "jpeg", "gif", "webp", "svg"].includes(ext)) type = "image";
    else if (["mp4", "mov", "avi", "webm"].includes(ext)) type = "video";
    else if (["mp3", "wav", "ogg"].includes(ext)) type = "audio";
    else if (["doc", "docx", "pdf", "txt", "xls", "xlsx", "ppt", "pptx", "odt"].includes(ext)) type = "document";

    const [row] = await db
      .insert(files)
      .values({
        name: file.name,
        originalName: file.name,
        path: `/uploads/${safeName}`,
        url: `/uploads/${safeName}`,
        size: bytes.length,
        mimeType: file.type || "application/octet-stream",
        extension: ext,
        type,
        category,
        folderId,
        userId: session.id,
      })
      .returning();
    saved.push(row);
  }

  return NextResponse.json({ success: true, data: saved });
}

export async function DELETE(request: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ success: false }, { status: 401 });
  const { searchParams } = new URL(request.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ success: false }, { status: 400 });
  await db.delete(files).where(eq(files.id, id));
  return NextResponse.json({ success: true });
}
